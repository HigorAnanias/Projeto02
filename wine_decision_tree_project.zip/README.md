# Projeto de Classificação com Árvore de Decisão - Wine Dataset

Este projeto implementa uma esteira de aprendizado de máquina usando a base de dados Wine do repositório UCI.

## Etapas do projeto

1. Carregamento da base de dados Wine (UCI)
2. Análise estatística descritiva
3. Transformações:
   - Coluna: normalização da variável 'alcohol'
   - Linha: remoção de outliers de 'malic_acid'
4. Divisão dos dados:
   - Treino (60%)
   - Validação (20%)
   - Teste (20%)
5. Treinamento de um modelo de Árvore de Decisão
6. Avaliação do modelo (acurácia e matriz de confusão)
7. Visualização da árvore de decisão
8. Predição em uma amostra do conjunto de teste

## Como executar

1. Clone este repositório ou baixe os arquivos:
```bash
git clone <URL_DO_REPOSITORIO>
cd wine_decision_tree_project
```

2. Instale as dependências:
```bash
pip install -r requirements.txt
```

3. Execute o notebook no Jupyter Notebook ou VS Code.

## Vídeo de Apresentação

[INCLUA AQUI O LINK DO VÍDEO APÓS GRAVAR E PUBLICAR NO YOUTUBE]

